package com.vehicle.demo.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
public class FitnessCertificateRequestDTO {

    private Long vehicleId;
    private String certificateNumber;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private String issuedBy;
}