package com.vehicle.demo.dto;

import lombok.Builder;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@Setter
@Getter
public class FitnessCertificateResponseDTO {

    private Long id;
    private Long vehicleId;
    private String certificateNumber;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private String issuedBy;
    private LocalDateTime createdAt;
}