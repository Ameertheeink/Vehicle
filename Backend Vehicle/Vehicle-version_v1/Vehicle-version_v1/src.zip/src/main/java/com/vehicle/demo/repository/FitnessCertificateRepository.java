package com.vehicle.demo.repository;

import com.vehicle.demo.entity.FitnessCertificate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface FitnessCertificateRepository
        extends JpaRepository<FitnessCertificate, Long> {

    List<FitnessCertificate> findByVehicleId(Long vehicleId);


}