package com.vehicle.demo.controller;

import com.vehicle.demo.dto.UpdateKmRequestDTO;
import com.vehicle.demo.dto.VehicleRequestDTO;
import com.vehicle.demo.dto.VehicleResponseDTO;
import com.vehicle.demo.dto.VehicleUpdateRequestDTO;
import com.vehicle.demo.service.VehicleService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/vehicles")
public class VehicleController {

    private final VehicleService vehicleService;

    public VehicleController(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @PostMapping
    public VehicleResponseDTO createVehicle(
            @RequestBody VehicleRequestDTO requestDTO) {

        return vehicleService.createVehicle(requestDTO);
    }
    @GetMapping
    public ResponseEntity<List<VehicleResponseDTO>> getAllVehicles() {
        return ResponseEntity.ok(vehicleService.getAllVehicles());
    }

    @PutMapping("/{id}/km")
    public ResponseEntity<VehicleResponseDTO> updateVehicleKm(
            @PathVariable Long id,
            @RequestBody UpdateKmRequestDTO requestDTO) {

        return ResponseEntity.ok(vehicleService.updateVehicleKm(id, requestDTO));
    }

//    @PutMapping("/{vehicleNumber}/km")
//    public ResponseEntity<VehicleResponseDTO> updateVehicleKm(
//            @PathVariable String vehicleNumber,
//            @RequestBody UpdateKmRequestDTO requestDTO) {
//
//        return ResponseEntity.ok(
//                vehicleService.updateVehicleKm(vehicleNumber, requestDTO)
//        );
//    }
//@PostMapping("/{vehicleNumber}/document")
//public ResponseEntity<String> uploadVehicleDocument(
//        @PathVariable String vehicleNumber,
//        @RequestParam("file") MultipartFile file) {
//
//    vehicleService.uploadDocument(vehicleNumber, file);
//    return ResponseEntity.ok("Document uploaded successfully");
//}

    @PostMapping("/{vehicleNumber}/document")
    public ResponseEntity<String> uploadVehicleDocument(
            @PathVariable String vehicleNumber,
            @RequestParam("file") MultipartFile file) {

        vehicleService.uploadDocument(vehicleNumber, file);
        return ResponseEntity.ok("Document uploaded successfully");
    }

    @GetMapping("/{vehicleNumber}/document")
    public ResponseEntity<byte[]> downloadVehicleDocument(
            @PathVariable String vehicleNumber) {

        byte[] fileData = vehicleService.getVehicleDocument(vehicleNumber);

        return ResponseEntity.ok()
                .header("Content-Disposition", "attachment; filename=document.pdf")
                .header("Content-Type", "application/pdf")
                .body(fileData);
    }

    @PutMapping("/{id}")
    public ResponseEntity<VehicleResponseDTO> updateVehicle(
            @PathVariable Long id,
            @RequestBody VehicleUpdateRequestDTO requestDTO) {

        return ResponseEntity.ok(vehicleService.updateVehicle(id, requestDTO));
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteVehicle(@PathVariable Long id) {

        vehicleService.deleteVehicle(id);
        return ResponseEntity.ok("Vehicle deleted successfully");
    }

    @PostMapping("/{id}/images")
    public ResponseEntity<String> uploadVehicleImages(
            @PathVariable Long id,
            @RequestParam("files") MultipartFile[] files) {

        vehicleService.uploadVehicleImages(id, files);
        return ResponseEntity.ok("Images uploaded successfully");
    }

}
